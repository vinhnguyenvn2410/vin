

```python
#does job satisfaction, income, age, gender... matter to employees?
#how can firms retain their talents in a cost-effective way? 
#If Job satisfaction matter, what improves job satisfaction?


#importing numpy, pandas and seaborn for visualization
import numpy as np
import pandas as pd
import random as rnd
import seaborn as sns
import sklearn.preprocessing as sk
import matplotlib.pyplot as plt
%matplotlib inline
```


```python
#reading the data with pandas. 
#I heard ppl described life was hell before pandas...
data = pd.read_csv('C:/Users/vinhnguyenvn2401/Downloads/ibm-hr-analytics-employee-attrition-performance/WA_Fn-UseC_-HR-Employee-Attrition.csv')
```


```python
#quick look at the data. Syntax is a bit different from R and C
data.head()
#AmateurHour: I should've change the attrition to 1/0 after checking for null.
#also do the same for BusinessTravel
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Attrition</th>
      <th>BusinessTravel</th>
      <th>DailyRate</th>
      <th>Department</th>
      <th>DistanceFromHome</th>
      <th>Education</th>
      <th>EducationField</th>
      <th>EmployeeCount</th>
      <th>EmployeeNumber</th>
      <th>...</th>
      <th>RelationshipSatisfaction</th>
      <th>StandardHours</th>
      <th>StockOptionLevel</th>
      <th>TotalWorkingYears</th>
      <th>TrainingTimesLastYear</th>
      <th>WorkLifeBalance</th>
      <th>YearsAtCompany</th>
      <th>YearsInCurrentRole</th>
      <th>YearsSinceLastPromotion</th>
      <th>YearsWithCurrManager</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>41</td>
      <td>Yes</td>
      <td>Travel_Rarely</td>
      <td>1102</td>
      <td>Sales</td>
      <td>1</td>
      <td>2</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>80</td>
      <td>0</td>
      <td>8</td>
      <td>0</td>
      <td>1</td>
      <td>6</td>
      <td>4</td>
      <td>0</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>49</td>
      <td>No</td>
      <td>Travel_Frequently</td>
      <td>279</td>
      <td>Research &amp; Development</td>
      <td>8</td>
      <td>1</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>2</td>
      <td>...</td>
      <td>4</td>
      <td>80</td>
      <td>1</td>
      <td>10</td>
      <td>3</td>
      <td>3</td>
      <td>10</td>
      <td>7</td>
      <td>1</td>
      <td>7</td>
    </tr>
    <tr>
      <th>2</th>
      <td>37</td>
      <td>Yes</td>
      <td>Travel_Rarely</td>
      <td>1373</td>
      <td>Research &amp; Development</td>
      <td>2</td>
      <td>2</td>
      <td>Other</td>
      <td>1</td>
      <td>4</td>
      <td>...</td>
      <td>2</td>
      <td>80</td>
      <td>0</td>
      <td>7</td>
      <td>3</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>33</td>
      <td>No</td>
      <td>Travel_Frequently</td>
      <td>1392</td>
      <td>Research &amp; Development</td>
      <td>3</td>
      <td>4</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>5</td>
      <td>...</td>
      <td>3</td>
      <td>80</td>
      <td>0</td>
      <td>8</td>
      <td>3</td>
      <td>3</td>
      <td>8</td>
      <td>7</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>27</td>
      <td>No</td>
      <td>Travel_Rarely</td>
      <td>591</td>
      <td>Research &amp; Development</td>
      <td>2</td>
      <td>1</td>
      <td>Medical</td>
      <td>1</td>
      <td>7</td>
      <td>...</td>
      <td>4</td>
      <td>80</td>
      <td>1</td>
      <td>6</td>
      <td>3</td>
      <td>3</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 35 columns</p>
</div>




```python
#The attributes/variables that this dataset provides
print(data.columns.values)
#some really cool variables that might support the current social uproars
```

    ['Age' 'Attrition' 'BusinessTravel' 'DailyRate' 'Department'
     'DistanceFromHome' 'Education' 'EducationField' 'EmployeeCount'
     'EmployeeNumber' 'EnvironmentSatisfaction' 'Gender' 'HourlyRate'
     'JobInvolvement' 'JobLevel' 'JobRole' 'JobSatisfaction' 'MaritalStatus'
     'MonthlyIncome' 'MonthlyRate' 'NumCompaniesWorked' 'Over18' 'OverTime'
     'PercentSalaryHike' 'PerformanceRating' 'RelationshipSatisfaction'
     'StandardHours' 'StockOptionLevel' 'TotalWorkingYears'
     'TrainingTimesLastYear' 'WorkLifeBalance' 'YearsAtCompany'
     'YearsInCurrentRole' 'YearsSinceLastPromotion' 'YearsWithCurrManager']
    


```python
#using isnull() or nunique() to figure out null values and unique values in this dataset
data.isnull().sum()
```




    Age                         0
    Attrition                   0
    BusinessTravel              0
    DailyRate                   0
    Department                  0
    DistanceFromHome            0
    Education                   0
    EducationField              0
    EmployeeCount               0
    EmployeeNumber              0
    EnvironmentSatisfaction     0
    Gender                      0
    HourlyRate                  0
    JobInvolvement              0
    JobLevel                    0
    JobRole                     0
    JobSatisfaction             0
    MaritalStatus               0
    MonthlyIncome               0
    MonthlyRate                 0
    NumCompaniesWorked          0
    Over18                      0
    OverTime                    0
    PercentSalaryHike           0
    PerformanceRating           0
    RelationshipSatisfaction    0
    StandardHours               0
    StockOptionLevel            0
    TotalWorkingYears           0
    TrainingTimesLastYear       0
    WorkLifeBalance             0
    YearsAtCompany              0
    YearsInCurrentRole          0
    YearsSinceLastPromotion     0
    YearsWithCurrManager        0
    dtype: int64




```python
data.nunique()
```




    Age                           43
    Attrition                      2
    BusinessTravel                 3
    DailyRate                    886
    Department                     3
    DistanceFromHome              29
    Education                      5
    EducationField                 6
    EmployeeCount                  1
    EmployeeNumber              1470
    EnvironmentSatisfaction        4
    Gender                         2
    HourlyRate                    71
    JobInvolvement                 4
    JobLevel                       5
    JobRole                        9
    JobSatisfaction                4
    MaritalStatus                  3
    MonthlyIncome               1349
    MonthlyRate                 1427
    NumCompaniesWorked            10
    Over18                         1
    OverTime                       2
    PercentSalaryHike             15
    PerformanceRating              2
    RelationshipSatisfaction       4
    StandardHours                  1
    StockOptionLevel               4
    TotalWorkingYears             40
    TrainingTimesLastYear          7
    WorkLifeBalance                4
    YearsAtCompany                37
    YearsInCurrentRole            19
    YearsSinceLastPromotion       16
    YearsWithCurrManager          18
    dtype: int64




```python
#1. just realized attrition means leaving. It's a Classification problem!!!
#2. we can see a lot of variations in income (dailyrate, monthlyrate, monhtly income)
#3. They are all over 18 so we can get rid of this column
#4. 37 values in yearsatcompany.
#5. Worklifebalance factor already numerical which is neataf
#6. JobInvolvement might be another factor that we should consider. 
#Or could it be merge with jobsatisfaction? Is it a combination of payrate and job involvement or they don't correlate at all?
#7. Attributes numerical as follows:
"""
EnvironmentSatisfaction 1 'Low' 2 'Medium' 3 'High' 4 'Very High'

JobInvolvement 
1 'Low' 2 'Medium' 3 'High' 4 'Very High'

JobSatisfaction 1 'Low' 2 'Medium' 3 'High' 4 'Very High'

PerformanceRating 
1 'Low' 2 'Good' 3 'Excellent' 4 'Outstanding'

RelationshipSatisfaction 
1 'Low' 2 'Medium' 3 'High' 4 'Very High'

WorkLifeBalance 1 'Bad' 2 'Good' 3 'Better' 4 'Best'
"""
```




    "\nEnvironmentSatisfaction 1 'Low' 2 'Medium' 3 'High' 4 'Very High'\n\nJobInvolvement \n1 'Low' 2 'Medium' 3 'High' 4 'Very High'\n\nJobSatisfaction 1 'Low' 2 'Medium' 3 'High' 4 'Very High'\n\nPerformanceRating \n1 'Low' 2 'Good' 3 'Excellent' 4 'Outstanding'\n\nRelationshipSatisfaction \n1 'Low' 2 'Medium' 3 'High' 4 'Very High'\n\nWorkLifeBalance 1 'Bad' 2 'Good' 3 'Better' 4 'Best'\n"




```python
data.describe()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>DailyRate</th>
      <th>DistanceFromHome</th>
      <th>Education</th>
      <th>EmployeeCount</th>
      <th>EmployeeNumber</th>
      <th>EnvironmentSatisfaction</th>
      <th>HourlyRate</th>
      <th>JobInvolvement</th>
      <th>JobLevel</th>
      <th>...</th>
      <th>RelationshipSatisfaction</th>
      <th>StandardHours</th>
      <th>StockOptionLevel</th>
      <th>TotalWorkingYears</th>
      <th>TrainingTimesLastYear</th>
      <th>WorkLifeBalance</th>
      <th>YearsAtCompany</th>
      <th>YearsInCurrentRole</th>
      <th>YearsSinceLastPromotion</th>
      <th>YearsWithCurrManager</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.0</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>...</td>
      <td>1470.000000</td>
      <td>1470.0</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>36.923810</td>
      <td>802.485714</td>
      <td>9.192517</td>
      <td>2.912925</td>
      <td>1.0</td>
      <td>1024.865306</td>
      <td>2.721769</td>
      <td>65.891156</td>
      <td>2.729932</td>
      <td>2.063946</td>
      <td>...</td>
      <td>2.712245</td>
      <td>80.0</td>
      <td>0.793878</td>
      <td>11.279592</td>
      <td>2.799320</td>
      <td>2.761224</td>
      <td>7.008163</td>
      <td>4.229252</td>
      <td>2.187755</td>
      <td>4.123129</td>
    </tr>
    <tr>
      <th>std</th>
      <td>9.135373</td>
      <td>403.509100</td>
      <td>8.106864</td>
      <td>1.024165</td>
      <td>0.0</td>
      <td>602.024335</td>
      <td>1.093082</td>
      <td>20.329428</td>
      <td>0.711561</td>
      <td>1.106940</td>
      <td>...</td>
      <td>1.081209</td>
      <td>0.0</td>
      <td>0.852077</td>
      <td>7.780782</td>
      <td>1.289271</td>
      <td>0.706476</td>
      <td>6.126525</td>
      <td>3.623137</td>
      <td>3.222430</td>
      <td>3.568136</td>
    </tr>
    <tr>
      <th>min</th>
      <td>18.000000</td>
      <td>102.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.0</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>30.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>...</td>
      <td>1.000000</td>
      <td>80.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>30.000000</td>
      <td>465.000000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>1.0</td>
      <td>491.250000</td>
      <td>2.000000</td>
      <td>48.000000</td>
      <td>2.000000</td>
      <td>1.000000</td>
      <td>...</td>
      <td>2.000000</td>
      <td>80.0</td>
      <td>0.000000</td>
      <td>6.000000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>3.000000</td>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>2.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>36.000000</td>
      <td>802.000000</td>
      <td>7.000000</td>
      <td>3.000000</td>
      <td>1.0</td>
      <td>1020.500000</td>
      <td>3.000000</td>
      <td>66.000000</td>
      <td>3.000000</td>
      <td>2.000000</td>
      <td>...</td>
      <td>3.000000</td>
      <td>80.0</td>
      <td>1.000000</td>
      <td>10.000000</td>
      <td>3.000000</td>
      <td>3.000000</td>
      <td>5.000000</td>
      <td>3.000000</td>
      <td>1.000000</td>
      <td>3.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>43.000000</td>
      <td>1157.000000</td>
      <td>14.000000</td>
      <td>4.000000</td>
      <td>1.0</td>
      <td>1555.750000</td>
      <td>4.000000</td>
      <td>83.750000</td>
      <td>3.000000</td>
      <td>3.000000</td>
      <td>...</td>
      <td>4.000000</td>
      <td>80.0</td>
      <td>1.000000</td>
      <td>15.000000</td>
      <td>3.000000</td>
      <td>3.000000</td>
      <td>9.000000</td>
      <td>7.000000</td>
      <td>3.000000</td>
      <td>7.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>60.000000</td>
      <td>1499.000000</td>
      <td>29.000000</td>
      <td>5.000000</td>
      <td>1.0</td>
      <td>2068.000000</td>
      <td>4.000000</td>
      <td>100.000000</td>
      <td>4.000000</td>
      <td>5.000000</td>
      <td>...</td>
      <td>4.000000</td>
      <td>80.0</td>
      <td>3.000000</td>
      <td>40.000000</td>
      <td>6.000000</td>
      <td>4.000000</td>
      <td>40.000000</td>
      <td>18.000000</td>
      <td>15.000000</td>
      <td>17.000000</td>
    </tr>
  </tbody>
</table>
<p>8 rows × 26 columns</p>
</div>




```python
#some employees live quite far away from work. 29 miles max but still less than from OC to LA
#max value for yearswithcurrentmanager is 17 years. Anything special about this?
```


```python
data.describe(include =['O'])
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Attrition</th>
      <th>BusinessTravel</th>
      <th>Department</th>
      <th>EducationField</th>
      <th>Gender</th>
      <th>JobRole</th>
      <th>MaritalStatus</th>
      <th>Over18</th>
      <th>OverTime</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1470</td>
      <td>1470</td>
      <td>1470</td>
      <td>1470</td>
      <td>1470</td>
      <td>1470</td>
      <td>1470</td>
      <td>1470</td>
      <td>1470</td>
    </tr>
    <tr>
      <th>unique</th>
      <td>2</td>
      <td>3</td>
      <td>3</td>
      <td>6</td>
      <td>2</td>
      <td>9</td>
      <td>3</td>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>top</th>
      <td>No</td>
      <td>Travel_Rarely</td>
      <td>Research &amp; Development</td>
      <td>Life Sciences</td>
      <td>Male</td>
      <td>Sales Executive</td>
      <td>Married</td>
      <td>Y</td>
      <td>No</td>
    </tr>
    <tr>
      <th>freq</th>
      <td>1233</td>
      <td>1043</td>
      <td>961</td>
      <td>606</td>
      <td>882</td>
      <td>326</td>
      <td>673</td>
      <td>1470</td>
      <td>1054</td>
    </tr>
  </tbody>
</table>
</div>




```python
#let's do some visualizing
#Let's see if there's any age discrimination when it comes to leaning...
import seaborn as sns
%matplotlib inline
g = sns.FacetGrid(data, col = 'Attrition')
g.map(plt.hist,'Age', bins = 5)
```




    <seaborn.axisgrid.FacetGrid at 0x1ce13ad4898>




![png](output_10_1.png)



```python
#many are fired within the 30years old range. however, because the employees' age 
#cluster around 30-40 years, we can't really conclude without % of attrition.
#attrition = 1 is the same from 40ish to near 60. However, there are twice as many employees within the 40-50 years old range than the 50-60
#-> there might be an age factor for the between 40-60 y.o range. Similar could be apply for the 20-30 range.
```


```python
#AmateurHour: I didn't see the attrition attribute was yes/no. Might as well turn it into 1 and 0 now
data["Attrition"] = data["Attrition"].astype('category')
data["Attrition_cat"] = data["Attrition"].cat.codes
#I used cat.codes to add a new column called attrition_cat as below. Cool!
```


```python
data.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Attrition</th>
      <th>BusinessTravel</th>
      <th>DailyRate</th>
      <th>Department</th>
      <th>DistanceFromHome</th>
      <th>Education</th>
      <th>EducationField</th>
      <th>EmployeeCount</th>
      <th>EmployeeNumber</th>
      <th>...</th>
      <th>StandardHours</th>
      <th>StockOptionLevel</th>
      <th>TotalWorkingYears</th>
      <th>TrainingTimesLastYear</th>
      <th>WorkLifeBalance</th>
      <th>YearsAtCompany</th>
      <th>YearsInCurrentRole</th>
      <th>YearsSinceLastPromotion</th>
      <th>YearsWithCurrManager</th>
      <th>Attrition_cat</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>41</td>
      <td>Yes</td>
      <td>Travel_Rarely</td>
      <td>1102</td>
      <td>Sales</td>
      <td>1</td>
      <td>2</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>80</td>
      <td>0</td>
      <td>8</td>
      <td>0</td>
      <td>1</td>
      <td>6</td>
      <td>4</td>
      <td>0</td>
      <td>5</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>49</td>
      <td>No</td>
      <td>Travel_Frequently</td>
      <td>279</td>
      <td>Research &amp; Development</td>
      <td>8</td>
      <td>1</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>2</td>
      <td>...</td>
      <td>80</td>
      <td>1</td>
      <td>10</td>
      <td>3</td>
      <td>3</td>
      <td>10</td>
      <td>7</td>
      <td>1</td>
      <td>7</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>37</td>
      <td>Yes</td>
      <td>Travel_Rarely</td>
      <td>1373</td>
      <td>Research &amp; Development</td>
      <td>2</td>
      <td>2</td>
      <td>Other</td>
      <td>1</td>
      <td>4</td>
      <td>...</td>
      <td>80</td>
      <td>0</td>
      <td>7</td>
      <td>3</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>33</td>
      <td>No</td>
      <td>Travel_Frequently</td>
      <td>1392</td>
      <td>Research &amp; Development</td>
      <td>3</td>
      <td>4</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>5</td>
      <td>...</td>
      <td>80</td>
      <td>0</td>
      <td>8</td>
      <td>3</td>
      <td>3</td>
      <td>8</td>
      <td>7</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>27</td>
      <td>No</td>
      <td>Travel_Rarely</td>
      <td>591</td>
      <td>Research &amp; Development</td>
      <td>2</td>
      <td>1</td>
      <td>Medical</td>
      <td>1</td>
      <td>7</td>
      <td>...</td>
      <td>80</td>
      <td>1</td>
      <td>6</td>
      <td>3</td>
      <td>3</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 36 columns</p>
</div>




```python
data["BusinessTravel"] = data["BusinessTravel"].astype('category')
data["BusinessTravel_cat"] = data["BusinessTravel"].cat.codes
data.head(20)
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Attrition</th>
      <th>BusinessTravel</th>
      <th>DailyRate</th>
      <th>Department</th>
      <th>DistanceFromHome</th>
      <th>Education</th>
      <th>EducationField</th>
      <th>EmployeeCount</th>
      <th>EmployeeNumber</th>
      <th>...</th>
      <th>StockOptionLevel</th>
      <th>TotalWorkingYears</th>
      <th>TrainingTimesLastYear</th>
      <th>WorkLifeBalance</th>
      <th>YearsAtCompany</th>
      <th>YearsInCurrentRole</th>
      <th>YearsSinceLastPromotion</th>
      <th>YearsWithCurrManager</th>
      <th>Attrition_cat</th>
      <th>BusinessTravel_cat</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>41</td>
      <td>Yes</td>
      <td>Travel_Rarely</td>
      <td>1102</td>
      <td>Sales</td>
      <td>1</td>
      <td>2</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>0</td>
      <td>8</td>
      <td>0</td>
      <td>1</td>
      <td>6</td>
      <td>4</td>
      <td>0</td>
      <td>5</td>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>1</th>
      <td>49</td>
      <td>No</td>
      <td>Travel_Frequently</td>
      <td>279</td>
      <td>Research &amp; Development</td>
      <td>8</td>
      <td>1</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>2</td>
      <td>...</td>
      <td>1</td>
      <td>10</td>
      <td>3</td>
      <td>3</td>
      <td>10</td>
      <td>7</td>
      <td>1</td>
      <td>7</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>37</td>
      <td>Yes</td>
      <td>Travel_Rarely</td>
      <td>1373</td>
      <td>Research &amp; Development</td>
      <td>2</td>
      <td>2</td>
      <td>Other</td>
      <td>1</td>
      <td>4</td>
      <td>...</td>
      <td>0</td>
      <td>7</td>
      <td>3</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>33</td>
      <td>No</td>
      <td>Travel_Frequently</td>
      <td>1392</td>
      <td>Research &amp; Development</td>
      <td>3</td>
      <td>4</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>5</td>
      <td>...</td>
      <td>0</td>
      <td>8</td>
      <td>3</td>
      <td>3</td>
      <td>8</td>
      <td>7</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>27</td>
      <td>No</td>
      <td>Travel_Rarely</td>
      <td>591</td>
      <td>Research &amp; Development</td>
      <td>2</td>
      <td>1</td>
      <td>Medical</td>
      <td>1</td>
      <td>7</td>
      <td>...</td>
      <td>1</td>
      <td>6</td>
      <td>3</td>
      <td>3</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>5</th>
      <td>32</td>
      <td>No</td>
      <td>Travel_Frequently</td>
      <td>1005</td>
      <td>Research &amp; Development</td>
      <td>2</td>
      <td>2</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>8</td>
      <td>...</td>
      <td>0</td>
      <td>8</td>
      <td>2</td>
      <td>2</td>
      <td>7</td>
      <td>7</td>
      <td>3</td>
      <td>6</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>6</th>
      <td>59</td>
      <td>No</td>
      <td>Travel_Rarely</td>
      <td>1324</td>
      <td>Research &amp; Development</td>
      <td>3</td>
      <td>3</td>
      <td>Medical</td>
      <td>1</td>
      <td>10</td>
      <td>...</td>
      <td>3</td>
      <td>12</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>7</th>
      <td>30</td>
      <td>No</td>
      <td>Travel_Rarely</td>
      <td>1358</td>
      <td>Research &amp; Development</td>
      <td>24</td>
      <td>1</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>11</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>8</th>
      <td>38</td>
      <td>No</td>
      <td>Travel_Frequently</td>
      <td>216</td>
      <td>Research &amp; Development</td>
      <td>23</td>
      <td>3</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>12</td>
      <td>...</td>
      <td>0</td>
      <td>10</td>
      <td>2</td>
      <td>3</td>
      <td>9</td>
      <td>7</td>
      <td>1</td>
      <td>8</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>9</th>
      <td>36</td>
      <td>No</td>
      <td>Travel_Rarely</td>
      <td>1299</td>
      <td>Research &amp; Development</td>
      <td>27</td>
      <td>3</td>
      <td>Medical</td>
      <td>1</td>
      <td>13</td>
      <td>...</td>
      <td>2</td>
      <td>17</td>
      <td>3</td>
      <td>2</td>
      <td>7</td>
      <td>7</td>
      <td>7</td>
      <td>7</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>10</th>
      <td>35</td>
      <td>No</td>
      <td>Travel_Rarely</td>
      <td>809</td>
      <td>Research &amp; Development</td>
      <td>16</td>
      <td>3</td>
      <td>Medical</td>
      <td>1</td>
      <td>14</td>
      <td>...</td>
      <td>1</td>
      <td>6</td>
      <td>5</td>
      <td>3</td>
      <td>5</td>
      <td>4</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>11</th>
      <td>29</td>
      <td>No</td>
      <td>Travel_Rarely</td>
      <td>153</td>
      <td>Research &amp; Development</td>
      <td>15</td>
      <td>2</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>15</td>
      <td>...</td>
      <td>0</td>
      <td>10</td>
      <td>3</td>
      <td>3</td>
      <td>9</td>
      <td>5</td>
      <td>0</td>
      <td>8</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>12</th>
      <td>31</td>
      <td>No</td>
      <td>Travel_Rarely</td>
      <td>670</td>
      <td>Research &amp; Development</td>
      <td>26</td>
      <td>1</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>16</td>
      <td>...</td>
      <td>1</td>
      <td>5</td>
      <td>1</td>
      <td>2</td>
      <td>5</td>
      <td>2</td>
      <td>4</td>
      <td>3</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>13</th>
      <td>34</td>
      <td>No</td>
      <td>Travel_Rarely</td>
      <td>1346</td>
      <td>Research &amp; Development</td>
      <td>19</td>
      <td>2</td>
      <td>Medical</td>
      <td>1</td>
      <td>18</td>
      <td>...</td>
      <td>1</td>
      <td>3</td>
      <td>2</td>
      <td>3</td>
      <td>2</td>
      <td>2</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>14</th>
      <td>28</td>
      <td>Yes</td>
      <td>Travel_Rarely</td>
      <td>103</td>
      <td>Research &amp; Development</td>
      <td>24</td>
      <td>3</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>19</td>
      <td>...</td>
      <td>0</td>
      <td>6</td>
      <td>4</td>
      <td>3</td>
      <td>4</td>
      <td>2</td>
      <td>0</td>
      <td>3</td>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>15</th>
      <td>29</td>
      <td>No</td>
      <td>Travel_Rarely</td>
      <td>1389</td>
      <td>Research &amp; Development</td>
      <td>21</td>
      <td>4</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>20</td>
      <td>...</td>
      <td>1</td>
      <td>10</td>
      <td>1</td>
      <td>3</td>
      <td>10</td>
      <td>9</td>
      <td>8</td>
      <td>8</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>16</th>
      <td>32</td>
      <td>No</td>
      <td>Travel_Rarely</td>
      <td>334</td>
      <td>Research &amp; Development</td>
      <td>5</td>
      <td>2</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>21</td>
      <td>...</td>
      <td>2</td>
      <td>7</td>
      <td>5</td>
      <td>2</td>
      <td>6</td>
      <td>2</td>
      <td>0</td>
      <td>5</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>17</th>
      <td>22</td>
      <td>No</td>
      <td>Non-Travel</td>
      <td>1123</td>
      <td>Research &amp; Development</td>
      <td>16</td>
      <td>2</td>
      <td>Medical</td>
      <td>1</td>
      <td>22</td>
      <td>...</td>
      <td>2</td>
      <td>1</td>
      <td>2</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>18</th>
      <td>53</td>
      <td>No</td>
      <td>Travel_Rarely</td>
      <td>1219</td>
      <td>Sales</td>
      <td>2</td>
      <td>4</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>23</td>
      <td>...</td>
      <td>0</td>
      <td>31</td>
      <td>3</td>
      <td>3</td>
      <td>25</td>
      <td>8</td>
      <td>3</td>
      <td>7</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>19</th>
      <td>38</td>
      <td>No</td>
      <td>Travel_Rarely</td>
      <td>371</td>
      <td>Research &amp; Development</td>
      <td>2</td>
      <td>3</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>24</td>
      <td>...</td>
      <td>0</td>
      <td>6</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
<p>20 rows × 37 columns</p>
</div>




```python
import seaborn as sns
%matplotlib inline
g = sns.FacetGrid(data, col = 'Attrition_cat')
g.map(plt.hist,'Age', bins = 5)

#this graph will be a bit better than the one above
```




    <seaborn.axisgrid.FacetGrid at 0x1ce16874048>




![png](output_15_1.png)



```python
#let do it once again with Gender
import seaborn as sns
%matplotlib inline
g = sns.FacetGrid(data, col = 'Attrition_cat')
g.map(plt.hist,'Gender', bins = 5)
```




    <seaborn.axisgrid.FacetGrid at 0x1ce168c7a90>




![png](output_16_1.png)



```python
#no biggie here in my opinion. The ratios reflect the differences in total employment.
#what are other factors that might contribute to Attrition?
#1. Age
#2. MonthlyIncome
import seaborn as sns
%matplotlib inline
g = sns.FacetGrid(data, col = 'Attrition_cat')
g.map(plt.hist,'MonthlyIncome', bins = 5)
```




    <seaborn.axisgrid.FacetGrid at 0x1ce13db6f28>




![png](output_17_1.png)



```python
#the folks who make good bucks at the firm tend to stay. It could be the money or the firm take care of them very well.
#the ratio makes sense where lower income folks are let go more often cuz it costs the company less in the long run
```


```python
#further proof of income that might help with the prediction
sns.jointplot(data.MonthlyIncome,data.Age, kind = 'scatter')
plt.show()
```


![png](output_19_0.png)



```python
import seaborn as sns
%matplotlib inline
g = sns.FacetGrid(data, col = 'Attrition_cat')
g.map(plt.hist,'BusinessTravel_cat', bins = 5)
```




    <seaborn.axisgrid.FacetGrid at 0x1ce16cc5eb8>




![png](output_20_1.png)



```python
#0 = non-travel
#1=  travel freq
#3 = travel rarely
#Once again it seems that this variable might not be material since there are more people who travel rarely and the ratio reflects the attrition population
```


```python
#this part i have to give credit to to DevenDray. His pairplots are too good.
col = ['Attrition', 'Age', 'MonthlyIncome','JobLevel','DistanceFromHome']
sns.pairplot(data[col], kind = 'reg', diag_kind = 'kde', hue = 'Attrition')
```




    <seaborn.axisgrid.PairGrid at 0x1ce37b08748>




![png](output_22_1.png)



```python
import seaborn as sns
%matplotlib inline
g = sns.FacetGrid(data, col = 'Attrition_cat')
g.map(plt.hist,'JobSatisfaction', bins = 5)
```




    <seaborn.axisgrid.FacetGrid at 0x1ce16cbacf8>




![png](output_23_1.png)



```python
#interesting! Job Satisfaction does matter. Almost double in population while similar Attrition.
```
